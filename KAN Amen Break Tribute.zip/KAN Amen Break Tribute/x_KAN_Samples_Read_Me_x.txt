

** Welcome to KAN Samples **


First of all, thank you for supporting our independent store!

We're thrilled to have you here and can't wait to hear what you create with our samples and presets.


_______________________________________


** Licensing Agreement **


By using this sample or preset pack, you agree to the following terms:

1. Usage Rights

- You are free to use these samples and/or presets in both commercial and non-commercial projects.

2. Royalty-Free

- All samples and/or presets in this pack are royalty-free, so you can use them without worrying about additional costs or royalties.

3. Prohibited Uses

- No sample or preset from this pack may be used in isolation in any public release. This means you cannot release, sell, or distribute any individual sample, preset or file from this pack.

4. Redistribution and Modification

- You may not redistribute or modify the samples or presets with the intent to sell to KAN Samples' competitors or the sample pack creators' competitors.

5. Sharing Restrictions

- Sharing download links or any files in this pack with anyone who has not purchased this pack from KAN Samples without written consent is prohibited by law.

_______________________________________


** Commitment to Our Community **


At KAN Samples, we are committed to fostering a strong and professional relationship with our customers.

We believe in collaboration, innovation, and mutual growth.

You can subscribe to our mailing list here: https://mailchi.mp/kansamples/trse7api5c

Here are a few ways we aim to support you:


--> Exclusive Content and Updates

Subscribe to our mailing list and stay tuned for exclusive content, updates, and special offers available only to our loyal customers.

We are constantly working on new releases and exciting features to enhance your music production experience.

And we aim to regularly give free valuable resources to our subscribers to help inspire your next session.


--> Feedback and Collaboration

Your feedback is invaluable to us.

We encourage you to share your thoughts, suggestions, and ideas.

Together, we can create better products that meet your needs and inspire your creativity.


--> Customer Support

Our dedicated support team is here to assist you with any questions or concerns.

We are committed to providing timely and helpful responses to ensure your experience with KAN Samples is smooth and enjoyable.


--> Community Engagement

Join our growing community of music producers.

Connect with like-minded individuals, share your projects, and gain inspiration from others.

We believe that a strong community can drive innovation and excellence.


_______________________________________


If you have any further questions or concerns, feel free to reach out to us.

Contact Us: support@kansamples.com

Thank you once again for choosing KAN Samples. Happy producing! 🎶

